
import streamlit as st
import pandas as pd
import numpy as np
import matplotlib.pyplot as plt

st.title("My First Streamlit App")
st.write("Welcome! This app is live on Streamlit Cloud.")

st.subheader("Sample Data Table")
data = pd.DataFrame({
    'Numbers': np.arange(1, 11),
    'Squares': np.arange(1, 11)**2
})
st.dataframe(data)

st.subheader("Numbers vs Squares")
plt.plot(data['Numbers'], data['Squares'], marker='o')
plt.xlabel("Numbers")
plt.ylabel("Squares")
st.pyplot(plt)
